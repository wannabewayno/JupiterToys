angular.module('jupiterApp').value('catalog', [{
	id: 1,
	title: "Teddy Bear",
	category: "Stuffed Toys",
	image: "images/src-embed/teddy.jpg",
	price: 12.99
},{
	id: 2,
	title: "Stuffed Frog",
	category: "Stuffed Toys",
	image: "images/src-embed/frog.jpg",
	price: 10.99
},{
	id: 3,
	title: "Handmade Doll",
	category: "Stuffed Toys",
	image: "images/src-embed/doll.jpg", 
	price: 10.99
},{
	id: 4,
	title: "Fluffy Bunny",
	category: "Stuffed Toys",
	image: "images/src-embed/bunny.jpg",
	price: 9.99
},{
	id: 5,
	title: "Smiley Bear",
	category: "Stuffed Toys",
	image: "images/src-embed/smiley.jpg",
	price: 14.99
},{
	id: 6,
	title: "Funny Cow",
	category: "Stuffed Toys",
	image: "images/src-embed/cow.jpg",
	price: 10.99
},{
	id: 7,
	title: "Valentine Bear",
	category: "Stuffed Toys",
	image: "images/src-embed/valentine.jpg",
	price: 14.99
},{
	id: 8,
	title: "Smiley Face",
	category: "Stuffed Toys",
	image: "images/src-embed/face.jpg",
	price: 9.99
}]);